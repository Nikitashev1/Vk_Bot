//token: '07223335940f1622b4b0a142ac76ba789c281089efc5c7cc82f1d75500d1d6b83e9850a6f924461ef7c5f'
const { VK, Keyboard } = require('vk-io');
const fs = require('fs');
const readline = require('readline');
const { SessionManager } = require('@vk-io/session');
const { SceneManager, StepScene } = require('@vk-io/scenes');

var Excel = require('exceljs');

var users = []

let rl = readline.createInterface({ //Open users.txt
    input: fs.createReadStream('users.txt')
});

let line_no = 0; //Set line position

rl.on('line', function(line) { //Read 'line be line' and split by ':' to get VK_ID and FACULTY_NAME
    //console.log(line);
    users[line_no] = line.split(':')
    line_no++;
});

rl.on('close', function(line) { //Report count of lines aka count of users
    console.log('Readed lines: ' + line_no + '\n');
    console.log(users) //Log users array
});

var workbook = new Excel.Workbook(); //Create excel workbook

var Groups1 = ['C11', 'D11', 'E11', 'F11', 'G11', 'H11', 'I11', 'J11', 'K11', 'L11', 'M11', 'N11', 'O11', 'P11', 'Q11', 'T11', 'U11', 'V11', 'W11', 'X11', 'Y11', 'Z11', 'AA11', 'AB11'] //Cells to get gruop names

var Borders1 = [13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109] //Cells to check bottom borders

var Letters1 = ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'AA', 'AB'] //Cells for group columns

var Groups2 = ['C11', 'D11', 'E11', 'F11', 'G11', 'H11', 'I11', 'J11', 'K11', 'N11', 'O11', 'P11', 'Q11', 'R11', 'S11', 'T11', 'U11', 'V11'] //Cells to get gruop names

var Borders2 = [13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109] //Cells to check bottom borders

var Letters2 = ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V'] //Cells for group columns

var Groups3 = ['C11', 'D11', 'E11', 'F11', 'G11', 'H11', 'I11', 'J11', 'K11', 'N11', 'O11', 'P11', 'Q11', 'R11', 'S11', 'T11', 'W11', 'Z11'] //Cells to get gruop names

var Borders3 = [13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109] //Cells to check bottom borders

var Letters3 = ['C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'W', 'Z'] //Cells for group columns

var Groups4 = ['C11', 'D11', 'E11', 'F11', 'I11', 'J11', 'K11'] //Cells to get gruop names

var Borders4 = [13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109] //Cells to check bottom borders

var Letters4 = ['C', 'D', 'E', 'F', 'I', 'J', 'K'] //Cells for group columns

var Groups5 = ['C11', 'D11', 'E11', 'F11', 'I11', 'J11', 'K11', 'L11', 'O11', 'P11', 'Q11', 'T11', 'U11', 'V11', 'Y11', 'AB11'] //Cells to get gruop names

var Borders5 = [13, 17, 21, 25, 29, 33, 37, 41, 45, 49, 53, 57, 61, 65, 69, 73, 77, 81, 85, 89, 93, 97, 101, 105, 109] //Cells to check bottom borders

var Letters5 = ['C', 'D', 'E', 'F', 'I', 'J', 'K', 'L', 'O', 'P', 'Q', 'T', 'U', 'V', 'Y', 'AB'] //Cells for group columns

function IsReg(UserID){
    for (var i = 0; i < users.length; i++){
        if (String(UserID) == String(users[i][0])){
            return true
        }
    }
    return false
}

function IsRightGroup(GroupID){
    for (var i = 0; i < FullTable.length; i++){
        if (String(GroupID) == String(FullTable[i][0])){
            return true
        }
    }
    return false
}

function isLetterR(str) {
    return str.length === 1 && str.match(/[А-Яа-я]/i);
}

function manyLettersR(str){
    var LetCount = 0
    for (var i = 0; i < str.length; i++){
        if (isLetterR(str.charAt(i))){
            LetCount++
        }
    }
    return LetCount
}

function isLetter(str) {
    return str.length === 1 && str.match(/[A-Z]/i);
}

function manyLetters(str){
    var LetCount = 0
    for (var i = 0; i < str.length; i++){
        if (isLetter(str.charAt(i))){
            LetCount++
        }
    }
    return LetCount
}

function getNext(str){
    var back = String(str.substr(0, manyLetters(str)))
    var next = parseInt(str.substr(manyLetters(str), str.length-manyLetters(str)))+1
    //console.log(back + next + '>' + str)
    return back + String(next)
}

function getPrev(str){
    var back = String(str.substr(0, manyLetters(str)))
    var prev = parseInt(str.substr(manyLetters(str), str.length-manyLetters(str)))-1
    //console.log(back + prev + '<' + str)
    return back + String(prev)
}

function isBorder(Cell) { //Check if there is a bottom border of this sell
    if (Cell.border.bottom){
        if (Cell.border.bottom.style == 'thin'){
            return true
        }else{
            return false
        }
    }
}

function getLessonHalf(t_worksheet, S_Cell) { //Get 2 cells value if separated on top and bottom
    //console.log(t_worksheet.getCell(S_Cell).value + ' : ' + t_worksheet.getCell(getPrev(S_Cell)).value + ' -> ' + S_Cell + ':' + getPrev(S_Cell))
    var tempStr = ''
    if (t_worksheet.getCell(getPrev(S_Cell)).value != null){
        tempStr += String(t_worksheet.getCell(getPrev(S_Cell)).value)
        tempStr += ' '
    }
    if (t_worksheet.getCell(S_Cell).value != null){
        tempStr += String(t_worksheet.getCell(S_Cell).value)
        tempStr += ' '
    }
    if (tempStr!=''){
        //console.log('R_H : ' + tempStr + '<<' + S_Cell)
    }
    return tempStr
}

function getLessonFull(t_worksheet, S_Cell) { //Get 4 cells value if NOT separated on top and bottom
    var tempStr = ''
    if (t_worksheet.getCell(getPrev(S_Cell)).value != null){
        tempStr += t_worksheet.getCell(getPrev(S_Cell)).value
        tempStr += ' '
    }
    if (t_worksheet.getCell(S_Cell).value != null){
        tempStr += t_worksheet.getCell(S_Cell).value
        tempStr += ' '
    }
    if (t_worksheet.getCell(getNext(S_Cell)).value != null){
        tempStr += t_worksheet.getCell(getNext(S_Cell)).value
        tempStr += ' '
    }
    if (t_worksheet.getCell(getNext(getNext(S_Cell))).value != null){
        tempStr += t_worksheet.getCell(getNext(getNext(S_Cell))).value
        tempStr += ' '
    }
    if (tempStr!=''){
        //console.log('R_F : ' + tempStr + '<<' + S_Cell)
    }
    return tempStr
}

var FullTable = []

function readExcel(FileName, SheetName, Groups, Borders, Letters){
    //console.log(':::Reading file : ' + FileName + ' sheet -> ' + SheetName)
    workbook.xlsx.readFile(FileName).then(function(Val){ //Open file with table to read, pass 'Val' so i can get access to global scope
        var worksheet = Val.getWorksheet(SheetName); //Get sheet to read
        for (var i = 0; i < Groups.length; i++){
            //console.log(worksheet.getCell(Groups[i]).value + '< - Group') //Log Group number
            var GroupTable = []; //Array for one group table
            var Up = []; //Array for top week day table
            var Down = []; //Array for bottom week day table
            var PairCount = 0; //Counter for classes per day
            for (var j = 0; j < Borders.length; j++){
                //console.log(j + ' : J >> ' + Borders[j]) //Log cell number to check bottom border(if this class separated to Top and Bottom)
                var CellAddr = Letters[i] + String(Borders[j]) //Create cell address
                //console.log(worksheet.getCell(CellAddr) + ' < - Cell at addr = ' + CellAddr)
                if (isBorder(worksheet.getCell(CellAddr))){ //Check is there a bottom border
                    //console.log('Push Up - > ' + String(getLessonHalf(worksheet, CellAddr)) + ' pos = ' + CellAddr) //Log Upper class
                    //console.log('Push Down - > ' + String(getLessonHalf(worksheet, Letters[i] + String(Borders[j]+2))) + ' pos = ' + Letters[i] + String(Borders[j]+2)) //Log Bottom class
                    Up.push(String(getLessonHalf(worksheet, CellAddr))); //Push upper class into array
                    Down.push(String(getLessonHalf(worksheet, Letters[i] + String(Borders[j]+2)))); //Push bottom class into array
                }else{
                    //console.log('Push All - > ' + String(getLessonFull(worksheet, CellAddr))) //Log 'both weeks' class
                    var PushLess = String(getLessonFull(worksheet, CellAddr)); //Get name of 'both weeks' class
                    Up.push(PushLess); //Push to Upper array
                    Down.push(PushLess); //Push to Bottom array
                }
                if (PairCount >= 4){ //If 5'th class in day
                    //console.log(N_Up + '<-Up')
                    //console.log(N_Down + '<-Down')
                    //Clome arrays because data in js array passing by reference
                    var N_Up = [...Up] //Clone Upper array
                    var N_Down = [...Down] //Clone Bottom array
                    var pushArr = [N_Up, N_Down] //Temp array to push
                    GroupTable.push(pushArr); //Push to one gruop array
                    PairCount = 0; //Reset class counter
                    Up = []; //Clear Upper array
                    Down = []; //Clear Bottom array
                    //console.log(N_Up + '<-Up')
                    //console.log(N_Down + '<-Down')
                }else{
                    PairCount++ //Otherwise increase counter
                }
            }
            //console.log(GroupTable)
            var N_GroupTable = [...GroupTable] //Clone one group table
            var Name_Group_Table = [String(worksheet.getCell(Groups[i])), N_GroupTable]
            var N_NGT = [...Name_Group_Table]
            FullTable.push(N_NGT) //Push to whole faculty array
        }
        //console.log(FullTable[5][4])
    });
}

readExcel('Table.xlsx', 'ОТФ2', Groups1, Borders1, Letters1)
readExcel('Table2.xlsx', 'ОТФ2', Groups2, Borders2, Letters2)
readExcel('Table3.xlsx', 'ОТФ1', Groups3, Borders3, Letters3)
readExcel('Table4.xlsx', 'ОТФ1', Groups4, Borders4, Letters4)
readExcel('Table5.xlsx', 'ФЭУ', Groups5, Borders5, Letters5)


/*
setTimeout(function(){
    console.log(FullTable[5][0])
    console.log(FullTable[5][1][0][1])
}, 5000);
*/

const vk = new VK({
	token: '0e0bd941cf6e7bed9c37652a357f0a1d55b0dfdedf5b0e0a87e8e08ef0d146c8e4d2fca2aaf4de125353a'
});

vk.updates.on('message', (context, next) => {
	const { messagePayload } = context;

	context.state.command = messagePayload && messagePayload.command
		? messagePayload.command
		: null;

	return next();
});

// Simple wrapper for commands
const hearCommand = (name, conditions, handle) => {
	if (typeof handle !== 'function') {
		handle = conditions;
		conditions = [`/${name}`];
	}

	if (!Array.isArray(conditions)) {
		conditions = [conditions];
	}

	vk.updates.hear(
		[
			(text, { state }) => (
				state.command === name
			),
			...conditions
		],
		handle
	);
};

var defKeyboard = Keyboard.keyboard([
                    [
                        Keyboard.textButton({
                            label: 'Изменить группу',
                            payload: {
                                command: 'changeGroup'
                            },
                            color: Keyboard.NEGATIVE_COLOR
                        }),
                        Keyboard.textButton({
                            label: 'Помошь',
                            payload: {
                                command: 'help'
                            }
                        })
                    ],
                    [    
                    Keyboard.textButton({
                            label: 'Сегодня',
                            payload: {
                                command: 'today'
                            },
                            color: Keyboard.PRIMARY_COLOR
                        }),
                        Keyboard.textButton({
                            label: 'Сейчас',
                            payload: {
                                command: 'now'
                            },
                            color: Keyboard.PRIMARY_COLOR
                        })
                    ],
                    [
                        Keyboard.textButton({
                            label: 'Следующие пары',
                            payload: {
                                command: 'next'
                            },
                            color: Keyboard.POSITIVE_COLOR
                        }),
                        Keyboard.textButton({
                            label: 'Завтра',
                            payload: {
                                command: 'tomorrow'
                            },
                            color: Keyboard.POSITIVE_COLOR
                        })
                    ],
                    Keyboard.textButton({
                        label: 'День недели',
                        payload: {
                            command: 'day'
                        },
                        color: Keyboard.POSITIVE_COLOR
                        })
                    ])

// Handle start button
hearCommand('start', (context, next) => {
	context.state.command = 'help';

	return Promise.all([
		next()
	]);
});

hearCommand('help', async (context) => {
    var IsReg = false
    for (var i = 0; i < users.length; i++){
        if (String(users[i][0]) == String(context.senderId)){
            //await context.send('Вы уже зарегистрированы!')
            IsReg = true
        }
    }
    if (!IsReg){
    await context.send({
		    message: `
            Oh, hi Mark!
            Я бот который подскажет тебе расписание, но для начала зарегистрируйся!
            Группа => три буквы + четыре цифры (Например: БВТ1904)
            1) Если что-то сломалось жми кнопку помощь и в лучшем случае все починится...
            2) Если есть неточности в расписании, нашел баг или есть предложения по новым функциям бота напиши ему: https://vk.com/nikitashev
            Команды:
            ▪️ Сегодня - узнать все пары на сегодня
            ▪️ Сейчас - узнать какая пара сейчас идет
            ▪️ Следующие пары - оставшиеся на сегодня пары
            ▪️ Завтра - пары на завтра
		    `,
		    keyboard: Keyboard.keyboard([
                [
                    Keyboard.textButton({
				        label: 'Регистрация',
				        payload: {
			        		command: 'reg'
                        },
                        color: Keyboard.NEGATIVE_COLOR
                    }),
                    Keyboard.textButton({
	    			    label: 'Помощь',
    				    payload: {
    					    command: 'help'
                        }
                    })
                ],
                [    
                Keyboard.textButton({
	    	    		label: 'Сегодня',
				        payload: {
				        	command: 'today'
                        },
                        color: Keyboard.PRIMARY_COLOR
                    }),
                    Keyboard.textButton({
				        label: 'Сейчас',
				        payload: {
					        command: 'now'
                        },
                        color: Keyboard.PRIMARY_COLOR
                    })
                ],
                [
                    Keyboard.textButton({
                        label: 'Следующие пары',
                        payload: {
                            command: 'next'
                        },
                        color: Keyboard.POSITIVE_COLOR
                    }),
                    Keyboard.textButton({
                        label: 'Завтра',
                        payload: {
                            command: 'tomorrow'
                        },
                        color: Keyboard.POSITIVE_COLOR
                    })
                ],
                Keyboard.textButton({
                    label: 'День недели',
                    payload: {
                        command: 'day'
                    },
                    color: Keyboard.POSITIVE_COLOR
                })
    		])
        });
        await context.sendSticker(2070)
    }else{
        await context.send({
		    message: `
        Oh, hi Mark!
        Я бот который подскажет тебе расписание!
        Группа => три буквы + четыре цифры (Например: БВТ1904)
        1) Если что-то сломалось жми кнопку помощь и в лучшем случае все починится...
        2) Если есть неточности в расписании, нашел баг или есть предложения по новым функциям бота напиши ему: https://vk.com/nikitashev
        Команды:
        ▪️ Сегодня - узнать все пары на сегодня
        ▪️ Сейчас - узнать какая пара сейчас идет
        ▪️ Следующие пары - оставшиеся на сегодня пары
        ▪️ Завтра - пары на завтра
		`,
		    keyboard: Keyboard.keyboard([
                [
                    Keyboard.textButton({
				        label: 'Изменить группу',
				        payload: {
			        		command: 'changeGroup'
                        },
                        color: Keyboard.NEGATIVE_COLOR
                    }),
                    Keyboard.textButton({
	    			    label: 'Помошь',
    				    payload: {
    					    command: 'help'
                        }
                    })
                ],
                [    
                Keyboard.textButton({
	    	    		label: 'Сегодня',
				        payload: {
				        	command: 'today'
                        },
                        color: Keyboard.PRIMARY_COLOR
                    }),
                    Keyboard.textButton({
				        label: 'Сейчас',
				        payload: {
					        command: 'now'
                        },
                        color: Keyboard.PRIMARY_COLOR
                    })
                ],
                [
                    Keyboard.textButton({
                        label: 'Следующие пары',
                        payload: {
                            command: 'next'
                        },
                        color: Keyboard.POSITIVE_COLOR
                    }),
                    Keyboard.textButton({
                        label: 'Завтра',
                        payload: {
                            command: 'tomorrow'
                        },
                        color: Keyboard.POSITIVE_COLOR
                    })
                ],
                Keyboard.textButton({
                    label: 'День недели',
                    payload: {
                        command: 'day'
                    },
                    color: Keyboard.POSITIVE_COLOR
                })
    		])
        });
        await context.sendSticker(2070)
    }
});

function IfZero(num){
    if (String(num).length == 1){
        return '0' + String(num)
    }else{
        return String(num)
    }
}

var Fst = new Date()
var Snd = new Date()
var Trd = new Date()
var Foth = new Date()
var Fith = new Date()

Fst.setHours(9, 30, 0)
Snd.setHours(11, 15, 0)
Trd .setHours(13, 00, 0)
Foth.setHours(15, 15, 0)
Fith.setHours(16, 55, 0)

var FstE = new Date()
var SndE = new Date()
var TrdE = new Date()
var FothE = new Date()
var FithE = new Date()

FstE.setHours(11, 05, 0)
SndE.setHours(12, 50, 0)
TrdE.setHours(14, 35, 0)
FothE.setHours(16, 45, 0)
FithE.setHours(18, 25, 0)


var TimesS = [Fst, Snd, Trd, Foth, Fith]
var TimesE = [FstE, SndE, TrdE, FothE, FithE]

//   0        1       2         3         4         5       6
//[Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday]

function getWeek(){ //What week is now (Top or Bottom classes in table)
    let now = new Date(); //curent date
    let onejan = new Date(now.getFullYear(),0,1); //getting current year 1'st jan
    var CurWeek = Math.ceil( (((now - onejan) / 86400000) + onejan.getDay() + 1) / 7 ); // return number of week in current year
    if (new Date().getDay>=5){
        CurWeek = CurWeek - 1
    }
    return CurWeek
}

function searchGroup(User_ID){
    for (var i = 0; i < users.length; i++){
        //console.log('Compare : ' + users[i][0] + ' to ' + String(User_ID) + ' by USER')
        if (users[i][0] == String(User_ID)){
            return String(users[i][1].substr(0, 3).toUpperCase()) + String(users[i][1].substr(3, 4))
        }
    }
    return -1
}

function searchID(Group_ID){
    for (var i = 0; i < FullTable.length; i++){
        //console.log('Compare : ' + FullTable[i][0] + ' to ' + String(Group_ID) + ' by GROUP')
        if (FullTable[i][0] == String(Group_ID)){
            return i
        }
    }
    return -1
}

hearCommand('today', async (context) => { //Command to get CURRENT day Table
    if (IsReg(context.senderId)){
        if (IsRightGroup(searchGroup(context.senderId))){
            var now = new Date().getDay()
            //var now = 3
            //console.log(getWeek() + ' : ' + now)
            var answer = '' //Future answer
            if ((now!=0) && (now!=6)){
                var G_ID = searchID(searchGroup(context.senderId))
                //console.log(context.senderId + ' : senderID')
                //console.log(G_ID + ' : Group ID')
                for (var i = 0; i < FullTable[G_ID][1][now-1][getWeek()%2].length; i++) { //Loop to check all classes at current day consider current week
                    if (FullTable[G_ID][1][now-1][getWeek()%2][i]!=''){
                        //console.log(i + ' <= i\'th ' + TimesS[i])
                        answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][now-1][getWeek()%2][i] //adding class to answer if it exist
                    }
                }
            }else{ //if Sunday or Saturday
                answer = answer + '\nСегодня нет занятий'
            }
            await context.send(answer) //Send answer
        }else{
            await context.send('Неверная группа!')
        }
    }else{
        await context.send('Вы еще не зарегистрированы!')
    }
});

hearCommand('now', async (context) => {
    if (IsReg(context.senderId)){
        if (IsRightGroup(searchGroup(context.senderId))){
            var now = new Date().getDay() // Get current day
            //var now = 1 //TEST
            var time = new Date() //get current time
            //time.setHours(13, 15)
            var answer = '' //Future answer
            if ((now!=0) && (now!=6)){
                var G_ID = searchID(searchGroup(context.senderId))
                var NonEmpty = 0
                for (var i = 0; i < FullTable[G_ID][1][now-1][getWeek()%2].length; i++) { //Loop to check all classes at current day consider current week
                    if (FullTable[G_ID][1][now-1][getWeek()%2][i]!=''){
                        if ((time > TimesS[i])&&(time < TimesE[i])&&(NonEmpty == 0)){
                            NonEmpty++
                            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][now-1][getWeek()%2][i] //adding class to answer if it exist
                        }
                    }
                }
                if (NonEmpty == 0){
                    answer = answer + '\nСейчас нет занятий'
                }
            }else{ //if Sunday or Saturday
                answer = answer + '\nСегодня нет занятий'
            }
            await context.send(answer) //Send answer
        }else{
            await context.send('Неверная группа!')
        }
    }else{
        await context.send('Вы еще не зарегистрированы!')
    }
});

hearCommand('next', async (context) => {
    if (IsReg(context.senderId)){
        if (IsRightGroup(searchGroup(context.senderId))){
            var now = new Date().getDay() // Get current day
            var time = new Date() //get current time
            //time.setHours(13, 15)
            var answer = '' //Future answer
            if ((now!=0) && (now!=6)){
                var G_ID = searchID(searchGroup(context.senderId))
                var NonEmpty = 0
                for (var i = 0; i < FullTable[G_ID][1][now-1][getWeek()%2].length; i++) { //Loop to check all classes at current day consider current week
                    if (FullTable[G_ID][1][now-1][getWeek()%2][i]!=''){
                        //console.log(String(time) + ' ::: ' + String(TimesS[i]) + ' res => ' + (time<TimesS[i]));
                        if (time<TimesS[i]){
                            NonEmpty++
                            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][now-1][getWeek()%2][i] //adding class to answer if it exist
                        }
                    }
                }
                if (NonEmpty == 0){
                    answer = answer + '\nСегодня больше нет занятий'
                }
            }else{ //if Sunday or Saturday
                answer = answer + '\nСегодня нет занятий'
            }
            await context.send(answer) //Send answer
        }else{
            await context.send('Неверная группа!')
        }
    }else{
        await context.send('Вы еще не зарегистрированы!')
    }
});

hearCommand('tomorrow', async (context) => { //Command to get CURRENT day Table
    if (IsReg(context.senderId)){
        if (IsRightGroup(searchGroup(context.senderId))){
            var now = new Date().getDay() + 1 //get next day of week
            if (now == 7){
                now=0
            }
            //var now = 6 //TEST
            var NewWeek = getWeek()
            //console.log(NewWeek) // < ----------- HERE TO TEST WEEK -----------------------------------------------------------------------------------------------------------------
            var answer = '' //Future answer
            if ((now!=0) && (now!=6)){
                var G_ID = searchID(searchGroup(context.senderId))
                for (var i = 0; i < FullTable[G_ID][1][now-1][NewWeek%2].length; i++) { //Loop to check all classes at (now + 1) day consider current week
                    if (FullTable[G_ID][1][now-1][NewWeek%2][i]!=''){
                        answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][now-1][getWeek()%2][i] //adding class to answer if it exist
                    }
                }
            }else{ //else Sunday or Saturday
                answer = answer + '\nЗавтра нет занятий'
            }
            await context.send(answer) //Send answer
        }else{
            await context.send('Неверная группа!')
        }
    }else{
        await context.send('Вы еще не зарегистрированы!')
    }
});

const sessionManager = new SessionManager();
const sceneManager = new SceneManager();

sceneManager.addScene(new StepScene('signup', [
	(context) => {
		if (context.scene.step.firstTime || !context.text) { //Asking to enter group number
			return context.send('Введите группу... (Пример: БВТ1904)'); //HERE KEYBOARD BUILDER --------------------------------------------------------------------------------------------------------
		}
        //console.log(manyLettersR(context.text))
        if ((context.text.length == 7) && (manyLettersR(context.text) == 3)){
            context.scene.state.GroupId = context.text; //Assign Group to variable
            context.scene.state.SceneUser = context.senderId; //Assign UserId to variable
            context.scene.state.IsGood = 1; //Means group number is correct
            return context.scene.step.next();
        }else{
            context.scene.state.IsGood = 0
            return context.scene.step.next(); //In case if person is stupid and cant enter correct gruop number first try
        }
	},
	async (context) => {
		const { GroupId, SceneUser, IsGood } = context.scene.state;
        if (IsGood == 1){    
            //console.log(SceneUser + ':' + GroupId + ' registering...') //Console debug
            var tempArr = [String(SceneUser), String(GroupId)]; //Temp array to push in users array
            users.push(tempArr);
		    await context.send(`Успешно зарегистрированы!`);
        }else{
            await context.send(`Неверная группа, повторите попытку...`);
        }
		await context.scene.leave(); //End scene
	}
]));

sceneManager.addScene(new StepScene('groupNumber', [
	(context) => {
		if (context.scene.step.firstTime || !context.text) { //Asking to enter group number
            return context.send('Введите группу... (Пример: БВТ1904)');
        }
        //console.log(manyLettersR(context.text))
        if ((context.text.length == 7) && (manyLettersR(context.text) == 3)){
            context.scene.state.GroupId = context.text; //Assign Group to variable
            context.scene.state.SceneUser = context.senderId; //Assign UserId to variable
            context.scene.state.IsGood = 1; //Means group number is correct
            return context.scene.step.next();
        }else{
            context.scene.state.IsGood = 0;
            return context.scene.step.next(); //In case if person is stupid and cant enter correct gruop number first try
        }
    },
	async (context) => {
		const { GroupId, SceneUser, IsGood } = context.scene.state;
        if (IsGood == 1){    
            //console.log(SceneUser + ':' + GroupId + ' registering...') //Console debug
            var tempArr = [String(SceneUser), String(GroupId)]; //Temp array to push in users array
            for (var i = 0; i < users.length; i++){ //Find person in array
                if (String(users[i][0]) == String(SceneUser)){
                    users[i] = tempArr; //Change old person info to new one
                }
            }
		    await context.send({message: `Успешно изменена группа!`, keyboard: defKeyboard});
        }else{
            await context.send(`Неверная группа, повторите попытку...`);
        }
		await context.scene.leave(); //End scene
	}
]));

/*
sceneManager.addScene(new StepScene('groupNumber', [
	(context) => {
		if (context.scene.step.firstTime || !context.text) { //Asking to enter group number
            return context.send('Введите группу...');
        }
        //console.log(manyLettersR(context.text))
        if ((context.text.length == 7) && (manyLettersR(context.text) == 3)){
            context.scene.state.GroupId = context.text; //Assign Group to variable
            context.scene.state.SceneUser = context.senderId; //Assign UserId to variable
            context.scene.state.IsGood = 1; //Means group number is correct
            return context.scene.step.next();
        }else{
            context.scene.state.IsGood = 0;
            return context.scene.step.next(); //In case if person is stupid and cant enter correct gruop number first try
        }
	},
	async (context) => {
		const { GroupId, SceneUser, IsGood } = context.scene.state;
        if (IsGood == 1){    
            //console.log(SceneUser + ':' + GroupId + ' registering...') //Console debug
            var tempArr = [String(SceneUser), String(GroupId)]; //Temp array to push in users array
            for (var i = 0; i < users.length; i++){ //Find person in array
                if (String(users[i][0]) == String(SceneUser)){
                    users[i] = tempArr; //Change old person info to new one
                }
            }
		    await context.send(`Успешно изменена группа!`);
        }else{
            await context.send(`Неверная группа, повторите попытку...`);
        }
		await context.scene.leave(); //End scene
	}
]));
*/

vk.updates.on('message', sessionManager.middleware);
vk.updates.on('message', sceneManager.middleware);
vk.updates.on('message', sceneManager.middlewareIntercept);

hearCommand('reg', async (context) => { //Registration command that starts scene for registration
    var UserId = context.senderId; //Author id
    var IsReg = false
    for (var i = 0; i < users.length; i++){ //Check if already registered
        if (String(users[i][0]) == String(UserId)){
            await context.send('Вы уже зарегистрированы!')
            IsReg = true
        }
    }
    if (!IsReg){
        await context.scene.enter('signup'); //Otherwise start scene
    }
});

hearCommand('changeGroup', async (context) => {
    await context.scene.enter('groupNumber'); //Start scene to change group number
});


hearCommand('monday', async (context) => {
    var now = new Date().getDay()
    var newWeek = getWeek()
    //console.log(now + ' : ' + newWeek)
    if ((now != 6)&&(now != 0)&&(now != 1)){
        //console.log('adding week')
        newWeek++
    }
    var answer = '' //Future answer
    var G_ID = searchID(searchGroup(context.senderId))
    //console.log(context.senderId + ' : senderID')
    //console.log(G_ID + ' : Group ID')
    for (var i = 0; i < FullTable[G_ID][1][0][newWeek%2].length; i++) { //Loop to check all classes at current day consider current week
        if (FullTable[G_ID][1][0][newWeek%2][i]!=''){
            //console.log(i + ' <= i\'th ' + TimesS[i])
            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][0][newWeek%2][i] //adding class to answer if it exist
        }
    }
    await context.send({message: answer, keyboard: defKeyboard}) //Send answer
})

hearCommand('tuesday', async (context) => {
    var now = new Date().getDay()
    var newWeek = getWeek()
    if ((now != 6)&&(now != 0)&&(now != 1)&&(now != 2)){
        newWeek++
    }
    var answer = '' //Future answer
    var G_ID = searchID(searchGroup(context.senderId))
    //console.log(context.senderId + ' : senderID')
    //console.log(G_ID + ' : Group ID')
    for (var i = 0; i < FullTable[G_ID][1][1][newWeek%2].length; i++) { //Loop to check all classes at current day consider current week
        if (FullTable[G_ID][1][1][newWeek%2][i]!=''){
            //console.log(i + ' <= i\'th ' + TimesS[i])
            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][1][newWeek%2][i] //adding class to answer if it exist
        }
    }
    await context.send({message: answer, keyboard: defKeyboard}) //Send answer
})

hearCommand('wednesday', async (context) => {
    var now = new Date().getDay()
    var newWeek = getWeek()
    if ((now != 6)&&(now != 0)&&(now != 1)&&(now != 2)&&(now != 3)){
        newWeek++
    }
    var answer = '' //Future answer
    var G_ID = searchID(searchGroup(context.senderId))
    //console.log(context.senderId + ' : senderID')
    //console.log(G_ID + ' : Group ID')
    for (var i = 0; i < FullTable[G_ID][1][2][newWeek%2].length; i++) { //Loop to check all classes at current day consider current week
        if (FullTable[G_ID][1][2][newWeek%2][i]!=''){
            //console.log(i + ' <= i\'th ' + TimesS[i])
            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][2][newWeek%2][i] //adding class to answer if it exist
        }
    }
    await context.send({message: answer, keyboard: defKeyboard}) //Send answer
})

hearCommand('thursday', async (context) => {
    var now = new Date().getDay()
    var newWeek = getWeek()
    if ((now != 6)&&(now != 0)&&(now != 1)&&(now != 2)&&(now != 3)&&(now != 4)){
        newWeek++
    }
    var answer = '' //Future answer
    var G_ID = searchID(searchGroup(context.senderId))
    //console.log(context.senderId + ' : senderID')
    //console.log(G_ID + ' : Group ID')
    for (var i = 0; i < FullTable[G_ID][1][3][newWeek%2].length; i++) { //Loop to check all classes at current day consider current week
        if (FullTable[G_ID][1][3][newWeek%2][i]!=''){
            //console.log(i + ' <= i\'th ' + TimesS[i])
            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][3][newWeek%2][i] //adding class to answer if it exist
        }
    }
    await context.send({message: answer, keyboard: defKeyboard}) //Send answer
})

hearCommand('friday', async (context) => {
    var now = new Date().getDay()
    var newWeek = getWeek()
    /*
    if ((now != 0)&&(now != 1)&&(now != 2)&&(now != 3)&&(now != 4)&&(now != 5)){
        newWeek++
    }
    */
    var answer = '' //Future answer
    var G_ID = searchID(searchGroup(context.senderId))
    //console.log(context.senderId + ' : senderID')
    //console.log(G_ID + ' : Group ID')
    for (var i = 0; i < FullTable[G_ID][1][4][newWeek%2].length; i++) { //Loop to check all classes at current day consider current week
        if (FullTable[G_ID][1][4][newWeek%2][i]!=''){
            //console.log(i + ' <= i\'th ' + TimesS[i])
            answer = answer + '\n' + IfZero(TimesS[i].getHours()) + ':' + IfZero(TimesS[i].getMinutes()) + '-' + IfZero(TimesE[i].getHours()) + ':' + IfZero(TimesE[i].getMinutes()) + ' - ' + FullTable[G_ID][1][4][newWeek%2][i] //adding class to answer if it exist
        }
    }
    await context.send({message: answer, keyboard: defKeyboard}) //Send answer
})

hearCommand('day', async (context) =>{
    if (IsReg(context.senderId)){
        if (IsRightGroup(searchGroup(context.senderId))){
            await context.send({
                message: 'Выбери день недели...',
                keyboard: Keyboard.keyboard([
                    [
                        Keyboard.textButton({
                            label: 'Понедельник',
                            payload: {
                                command: 'monday'
                            },
                            color: Keyboard.NEGATIVE_COLOR
                        }),
                        Keyboard.textButton({
                            label: 'Вторник',
                            payload: {
                                command: 'tuesday'
                            },
                            color: Keyboard.PRIMARY_COLOR
                        })
                    ],
                    [    
                    Keyboard.textButton({
                            label: 'Среда',
                            payload: {
                                command: 'wednesday'
                            },
                            color: Keyboard.PRIMARY_COLOR
                        }),
                        Keyboard.textButton({
                            label: 'Четверг',
                            payload: {
                                command: 'thursday'
                            },
                            color: Keyboard.PRIMARY_COLOR
                        })
                    ],
                    Keyboard.textButton({
                        label: 'Пятница',
                        payload: {
                            command: 'friday'
                        },
                        color: Keyboard.POSITIVE_COLOR
                    })
                ])
            })
        }else{
            await context.send('Неверная группа!')
        }
    }else{
        await context.send('Вы еще не зарегистрированы!')
    }
});

hearCommand('read', async (context) => {  //Read cells in excel

});


vk.updates.start().catch(console.error);

process.on('exit', function(){ //on process exit save file with registered users
    fs.writeFile('users.txt', '', function(){console.log('users.txt cleared...')})
    for (var i = 0; i < users.length; i++) {
        var UserAndId = users[i][0] + ':' + users[i][1] + '\n' //Create user registration string
        fs.appendFileSync('users.txt', UserAndId); //Write string to file
    }
    console.log("users.txt saved!");
});

process.stdin.setEncoding('utf-8');

process.stdin.on('data', function (data) { //force exit

    // User input exit.
    if(data == 1){
        // Program exit.
        console.log("User input complete, program exit.");
        process.exit();
    }else{
        // Otherwise say what to do for exit
        console.log('Type \'1\' to exit the process and save users.txt');
    }
});