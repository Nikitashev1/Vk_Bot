import * as fs from 'async-file';
(async function () {
    var list = await fs.readdir('.');
    console.log(list);    
})();